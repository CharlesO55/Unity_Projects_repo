~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
+-------------------------------------------------------------+
|                           READ ME                           |
+-------------------------------------------------------------+
~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~

1. Create a [Resources] folder in the Unity [Assets] folder.

2. Recreate the folder structure of this provided folder in
   your Unity [Resources] folder.

3. Note that only the [Sprites] folder has content. The other
   folders are simply there to guide you on the proper folder
   structure.